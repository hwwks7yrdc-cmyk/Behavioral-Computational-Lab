# Comprehension quiz – answer key (pgg_partner)

**1. You contribute 0 points and each of the other 3 members contributes 20 points. What are your earnings in this round?**

Answer: **44**. Group total = 60. Each member receives 0.4 × 60 = 24 from the group account. Kept in private account: 20. Earnings = 44.

**2. You contribute 20 points and each of the other 3 members contributes 20 points. What are your earnings in this round?**

Answer: **32**. Group total = 80. Each member receives 0.4 × 80 = 32 from the group account. Kept in private account: 0. Earnings = 32.

**3. You contribute 3 points and the other members contribute 10, 16, 16 points. What are Member 2's earnings in this round?**

Answer: **28**. Group total = 45. Each member receives 0.4 × 45 = 18 from the group account. Kept in private account: 10. Earnings = 28.

**4. You contribute 7 points and the other members contribute 19, 19, 17 points. What are your earnings in this round?**

Answer: **37.8**. Group total = 62. Each member receives 0.4 × 62 = 24.8 from the group account. Kept in private account: 13. Earnings = 37.8.
