# Session checklist – Public Goods Game (partner matching)

Session config: `pgg_partner` · participants per session: **16** (4 groups of 4) · 10 round(s), partner matching.

## Before the session
- [ ] Run `otree test pgg_partner` and confirm all bot cases pass.
- [ ] Create the session in the oTree admin with exactly a multiple of 4 participants (room links or session-wide link).
- [ ] Print the instructions (instructions.md) and the payment receipts; keep the quiz answer key at the experimenter desk.
- [ ] Check that the IRB-approved consent form is the one shown to participants.
- [ ] Prepare cash or transfer for up to 496.00 CNY (expected range 400.00–496.00 CNY).

## During the session
- [ ] Read the instructions aloud while participants follow on screen (common knowledge of the rules).
- [ ] Watch the monitor for participants stuck on the quiz (max 3 attempts; failures are recorded in `quiz_gave_up`).
- [ ] Do not answer questions about strategy; repeat the relevant part of the instructions instead.
- [ ] Note any irregularities (late arrivals, crashes, talking) in the session log with the participant code.

## After the session
- [ ] Download the data via *Data → Custom export* (tidy long format) and the standard *All apps* export.
- [ ] Pay participants privately using the payment report; record payments against participant codes.
- [ ] Store data according to the data management plan; remove direct identifiers.

## Key numbers
- Estimated duration: about 35 minutes.
- Earnings per round: 8 to 44 points (all contribute: 32; nobody contributes: 20).
- Payment per person: 19.00 to 37.00 CNY incl. participation fee of 15.00 CNY.
