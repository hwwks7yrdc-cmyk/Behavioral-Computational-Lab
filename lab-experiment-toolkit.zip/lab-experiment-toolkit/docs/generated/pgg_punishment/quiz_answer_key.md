# Comprehension quiz – answer key (pgg_punishment)

**1. You contribute 0 points and each of the other 3 members contributes 20 points. What are your earnings in this round before any deduction points?**

Answer: **44**. Group total = 60. Each member receives 0.4 × 60 = 24 from the group account. Kept in private account: 20. Earnings = 44.

**2. You contribute 20 points and each of the other 3 members contributes 20 points. What are your earnings in this round before any deduction points?**

Answer: **32**. Group total = 80. Each member receives 0.4 × 80 = 32 from the group account. Kept in private account: 0. Earnings = 32.

**3. In the deduction stage you assign 3 points to Member 2. By how many points are your own earnings reduced?**

Answer: **3**. Each point you assign costs you 1: 3 × 1 = 3.

**4. Member 2 receives 3 deduction points in total. By how many points are Member 2's earnings reduced?**

Answer: **9**. Each point received reduces earnings by 3: 3 × 3 = 9.

**5. You contribute 11 points and the other members contribute 5, 0, 11 points. What are your earnings in this round before any deduction points?**

Answer: **19.8**. Group total = 27. Each member receives 0.4 × 27 = 10.8 from the group account. Kept in private account: 9. Earnings = 19.8.
