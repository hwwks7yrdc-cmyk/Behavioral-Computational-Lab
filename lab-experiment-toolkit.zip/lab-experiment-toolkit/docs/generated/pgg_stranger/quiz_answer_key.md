# Comprehension quiz – answer key (pgg_stranger)

**1. You contribute 0 points and each of the other 3 members contributes 20 points. What are your earnings in this round?**

Answer: **44**. Group total = 60. Each member receives 0.4 × 60 = 24 from the group account. Kept in private account: 20. Earnings = 44.

**2. You contribute 20 points and each of the other 3 members contributes 20 points. What are your earnings in this round?**

Answer: **32**. Group total = 80. Each member receives 0.4 × 80 = 32 from the group account. Kept in private account: 0. Earnings = 32.

**3. You contribute 3 points and the other members contribute 14, 2, 0 points. What are Member 3's earnings in this round?**

Answer: **25.6**. Group total = 19. Each member receives 0.4 × 19 = 7.6 from the group account. Kept in private account: 18. Earnings = 25.6.

**4. You contribute 20 points and the other members contribute 5, 12, 5 points. What are your earnings in this round?**

Answer: **16.8**. Group total = 42. Each member receives 0.4 × 42 = 16.8 from the group account. Kept in private account: 0. Earnings = 16.8.
