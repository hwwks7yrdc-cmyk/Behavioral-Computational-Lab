## Instructions

### Overview

You are now taking part in a study of decision making. Please read these instructions carefully. Your earnings depend on your own decisions and on the decisions of other participants.

You will be randomly assigned to a group of **4 participants**. You will stay in the **same group for all 10 rounds**. You will not learn who the other members of your group are, and they will not learn who you are.

### Your decision in each round

At the beginning of each round you receive **20 points**. You decide how many of these points to put into a **group account**. You can contribute any whole number of points from 0 to 20. The points you do not contribute stay in your **private account**.

### How your earnings are calculated

- Every point in your private account is worth one point to you.
- The points contributed by all members of your group are added up. If this total is at least **48 points**, then every member receives **0.4 points for every point in the group account**, no matter who contributed it.
- If the total is **below 48 points**, the group account pays nothing. In that case every member gets their own contribution back.

In short, your earnings in a round are:

**(points kept in your private account) + 0.4 × (total points in the group account), if the total reaches 48**

### Example

Suppose you contribute 10 points and the other members contribute 20, 13, 7 points. The group account then contains 50 points. This reaches the threshold of 48.

Your earnings: 10 points in your private account + 20 points from the group account (0.4 × 50) = **30 points**. A member who contributed 20 earns 20 points.

### After each round

At the end of each round you see the contributions of your group and your earnings. A table shows your results from earlier rounds. You have 90 seconds for each decision; if you do not decide in time, your contribution is recorded as 0.

### Payment

At the end of the study, **one round is selected at random**, and you are paid your earnings from that round. Every round is equally likely to be selected, so please treat every round as if it were the one that counts. Points are converted into money at a rate of **2 points = 1 CNY**. In addition, you receive a participation fee of **15.00 CNY**.

### Before you start

You will answer 4 short questions to check that the rules are clear. If you have a question at any time, please raise your hand.
