# Comprehension quiz – answer key (pgg_threshold)

**1. You contribute 0 points and each of the other 3 members contributes 20 points. What are your earnings in this round?**

Answer: **44**. Group total = 60. The threshold of 48 is reached. Each member receives 0.4 × 60 = 24 from the group account. Kept in private account: 20. Earnings = 44.

**2. You contribute 20 points and each of the other 3 members contributes 20 points. What are your earnings in this round?**

Answer: **32**. Group total = 80. The threshold of 48 is reached. Each member receives 0.4 × 80 = 32 from the group account. Kept in private account: 0. Earnings = 32.

**3. You contribute 20 points and the other members contribute 20, 7, 0 points. What are your earnings in this round?**

Answer: **20**. Group total = 47. The threshold of 48 is not reached. Kept in private account: 20. Earnings = 20.

**4. You contribute 15 points and the other members contribute 15, 5, 5 points. What are Member 3's earnings in this round?**

Answer: **20**. Group total = 40. The threshold of 48 is not reached. Kept in private account: 20. Earnings = 20.
