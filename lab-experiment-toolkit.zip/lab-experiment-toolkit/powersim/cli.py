"""powersim command line interface.

    powersim --sessions 2 3 4 6 8 10 --effect 0 0.10 --reps 1000 --out results.csv --plot power.png
    powersim --required --effect 0.10       # analytic number of sessions per arm for 80% power
"""
from __future__ import annotations

import argparse
from dataclasses import fields, replace

from .simulate import Design, analytic_power_session_means, power_grid, required_sessions

LABELS = {
    "ols_iid": "OLS, i.i.d. SE",
    "cr_subject": "OLS, clustered by participant",
    "cr_group": "OLS, clustered by group",
    "cr_session": "OLS, clustered by session (CR1)",
    "session_means": "t-test on session means",
    "wild_session": "Wild cluster bootstrap (session)",
}


def plot(df, path, alpha=0.05):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    effects = sorted(df.effect.unique())
    fig, axes = plt.subplots(1, len(effects), figsize=(5.2 * len(effects), 4.2), sharex=True)
    if len(effects) == 1:
        axes = [axes]
    for ax, eff in zip(axes, effects):
        sub = df[df.effect == eff]
        for est, label in LABELS.items():
            s = sub[sub.estimator == est].sort_values("sessions_per_arm")
            ax.errorbar(s.sessions_per_arm, s.rejection_rate, yerr=1.96 * s.mc_se, marker="o", ms=4, capsize=2, label=label)
        if eff == 0:
            ax.axhline(alpha, color="k", ls="--", lw=1)
            ax.set_title("Size: rejection rate under H0 (effect = 0)")
        else:
            ax.axhline(0.8, color="k", ls=":", lw=1)
            ax.set_title(f"Power: effect = {eff:g} on the contribution share")
        ax.set_xlabel("Sessions per treatment arm")
        ax.set_ylabel("Rejection rate at α = 0.05")
        ax.set_ylim(0, 1)
        ax.grid(alpha=0.3)
    axes[-1].legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(path, dpi=160)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="powersim", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sessions", type=int, nargs="+", default=[2, 3, 4, 6, 8, 10])
    ap.add_argument("--effect", type=float, nargs="+", default=[0.0, 0.10])
    ap.add_argument("--reps", type=int, default=1000)
    ap.add_argument("--bootstrap", type=int, default=399)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default=None)
    ap.add_argument("--plot", default=None)
    ap.add_argument("--required", action="store_true", help="print the analytic number of sessions per arm for 80%% power")
    for f in fields(Design):
        if f.name in ("sessions_per_arm", "effect"):
            continue
        typ = type(f.default)
        if typ is bool:
            ap.add_argument(f"--{f.name.replace('_', '-')}", type=lambda s: s.lower() in ("1", "true", "yes"), default=f.default)
        else:
            ap.add_argument(f"--{f.name.replace('_', '-')}", type=typ, default=f.default)
    a = ap.parse_args(argv)
    base = Design(**{f.name: getattr(a, f.name) for f in fields(Design) if f.name not in ("sessions_per_arm", "effect")})

    if a.required:
        for eff in a.effect:
            if eff == 0:
                continue
            k = required_sessions(replace(base, effect=eff))
            if k is None:
                print(f"effect {eff:g}: more than 60 sessions per arm needed for 80% power")
                continue
            p = analytic_power_session_means(replace(base, effect=eff, sessions_per_arm=k))
            print(f"effect {eff:g}: {k} sessions per arm ({k * base.subjects_per_session} participants per arm), analytic power {p:.2f}")
        return 0

    df = power_grid(base, sessions=a.sessions, effects=a.effect, reps=a.reps, B=a.bootstrap, seed=a.seed)
    table = df.pivot_table(index=["effect", "sessions_per_arm"], columns="estimator", values="rejection_rate")
    print(table.round(3).to_string())
    if a.out:
        df.to_csv(a.out, index=False)
    if a.plot:
        plot(df, a.plot)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
