"""Simulation-based power and size for laboratory experiments with session-level treatment assignment.

In many lab experiments the treatment is assigned to whole sessions (all
participants in a session see the same condition), groups are nested in
sessions, and each participant decides in several rounds. Observations are then
correlated at several levels, and the number of independent units is the number
of sessions, not the number of decisions.

This module simulates such data and compares estimators:

``ols_iid``          OLS on all decisions with i.i.d. standard errors (common, wrong)
``cr_subject``       OLS clustered by participant
``cr_group``         OLS clustered by group
``cr_session``       OLS clustered by session (CR1, t with S-1 df)
``session_means``    Welch t-test on session means
``wild_session``     wild cluster bootstrap-t at the session level, restricted, Webb weights

All estimators exploit the structure of the problem (one binary regressor that
is constant within sessions), so a replication costs microseconds and thousands
of replications run in seconds. ``tests/test_powersim.py`` checks the closed forms
against statsmodels.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace

import numpy as np
import pandas as pd
from scipy import stats

ESTIMATORS = ("ols_iid", "cr_subject", "cr_group", "cr_session", "session_means", "wild_session")

# Webb (2014) six-point weights: better than Rademacher when clusters are few
WEBB = np.array([-np.sqrt(1.5), -1.0, -np.sqrt(0.5), np.sqrt(0.5), 1.0, np.sqrt(1.5)])


@dataclass(frozen=True)
class Design:
    sessions_per_arm: int = 4
    groups_per_session: int = 4
    group_size: int = 4
    rounds: int = 10
    baseline: float = 0.45           # mean contribution share in the control condition
    effect: float = 0.0              # treatment effect on the contribution share
    sd: float = 0.35                 # total SD of a single decision (before censoring)
    icc_session: float = 0.03        # share of variance at the session level
    icc_group: float = 0.10          # ... at the group level
    icc_subject: float = 0.30        # ... at the participant level
    decay: float = -0.02             # linear change per round (centred), common to both arms
    clip: bool = True                # censor shares to [0, 1] as in real contribution data

    def __post_init__(self):
        if self.sessions_per_arm < 2:
            raise ValueError("need at least 2 sessions per arm")
        if min(self.icc_session, self.icc_group, self.icc_subject) < 0 or (
            self.icc_session + self.icc_group + self.icc_subject >= 1
        ):
            raise ValueError("variance shares must be non-negative and sum to less than 1")

    @property
    def subjects_per_session(self) -> int:
        return self.groups_per_session * self.group_size

    @property
    def n_sessions(self) -> int:
        return 2 * self.sessions_per_arm


# ------------------------------------------------------------------ data generation
def simulate_data(d: Design, rng: np.random.Generator) -> dict[str, np.ndarray]:
    """Return arrays of length N (= sessions x subjects x rounds) with ids and outcome."""
    S, G, n, R = d.n_sessions, d.groups_per_session, d.group_size, d.rounds
    var = d.sd ** 2
    resid_share = 1 - d.icc_session - d.icc_group - d.icc_subject

    treat_s = np.repeat([0.0, 1.0], d.sessions_per_arm)
    u_s = rng.normal(0, np.sqrt(var * d.icc_session), S)
    v_g = rng.normal(0, np.sqrt(var * d.icc_group), (S, G))
    w_i = rng.normal(0, np.sqrt(var * d.icc_subject), (S, G, n))
    e = rng.normal(0, np.sqrt(var * resid_share), (S, G, n, R))
    trend = d.decay * (np.arange(1, R + 1) - (R + 1) / 2)

    y = (
        d.baseline
        + d.effect * treat_s[:, None, None, None]
        + u_s[:, None, None, None]
        + v_g[:, :, None, None]
        + w_i[:, :, :, None]
        + trend[None, None, None, :]
        + e
    )
    if d.clip:
        y = np.clip(y, 0.0, 1.0)

    session = np.broadcast_to(np.arange(S)[:, None, None, None], y.shape)
    group = np.broadcast_to((np.arange(S)[:, None] * G + np.arange(G)[None, :])[:, :, None, None], y.shape)
    subject = np.broadcast_to(np.arange(S * G * n).reshape(S, G, n)[:, :, :, None], y.shape)
    treat = np.broadcast_to(treat_s[:, None, None, None], y.shape)
    return dict(
        y=y.ravel(),
        treat=treat.ravel().copy(),
        session=session.ravel().copy(),
        group=group.ravel().copy(),
        subject=subject.ravel().copy(),
    )


# ------------------------------------------------------------------ closed-form estimators
def _diff_and_resid(y, treat):
    t = treat == 1
    m1, m0 = y[t].mean(), y[~t].mean()
    resid = y - np.where(t, m1, m0)
    return m1 - m0, resid, t.sum(), (~t).sum()


def ols_iid(y, treat):
    """Difference in means with the classical OLS standard error; returns (beta, se, df)."""
    beta, resid, n1, n0 = _diff_and_resid(y, treat)
    N = len(y)
    s2 = (resid ** 2).sum() / (N - 2)
    return beta, np.sqrt(s2 * (1 / n1 + 1 / n0)), N - 2


def ols_cluster(y, treat, cluster):
    """OLS of y on a constant and a cluster-level dummy with CR1 standard errors.

    Clusters must be nested within treatment arms. Returns (beta, se, df) with df = G - 1.
    """
    beta, resid, n1, n0 = _diff_and_resid(y, treat)
    N = len(y)
    codes, inv = np.unique(cluster, return_inverse=True)
    Gc = len(codes)
    E = np.bincount(inv, weights=resid, minlength=Gc)
    arm = np.bincount(inv, weights=treat, minlength=Gc) / np.bincount(inv, minlength=Gc)
    if not np.all((arm == 0) | (arm == 1)):
        raise ValueError("clusters must be nested within treatment arms")
    v = ((E[arm == 1] / n1) ** 2).sum() + ((E[arm == 0] / n0) ** 2).sum()
    v *= Gc / (Gc - 1) * (N - 1) / (N - 2)
    return beta, np.sqrt(v), Gc - 1


def session_means_test(y, treat, session):
    codes, inv = np.unique(session, return_inverse=True)
    means = np.bincount(inv, weights=y) / np.bincount(inv)
    arm = np.bincount(inv, weights=treat) / np.bincount(inv)
    res = stats.ttest_ind(means[arm == 1], means[arm == 0], equal_var=False)
    return float(means[arm == 1].mean() - means[arm == 0].mean()), float(res.pvalue)


def wild_cluster_bootstrap(y, treat, cluster, rng, B=399, weights="webb"):
    """Restricted wild cluster bootstrap-t (WCR) p-value for H0: beta = 0.

    Works entirely with cluster sums of the restricted residuals, so each bootstrap
    draw costs O(G).
    """
    beta, se, _ = ols_cluster(y, treat, cluster)
    t_obs = beta / se
    N = len(y)
    codes, inv = np.unique(cluster, return_inverse=True)
    Gc = len(codes)
    m_c = np.bincount(inv, minlength=Gc).astype(float)
    arm = (np.bincount(inv, weights=treat, minlength=Gc) / m_c) == 1
    n1, n0 = m_c[arm].sum(), m_c[~arm].sum()
    S0 = np.bincount(inv, weights=y - y.mean(), minlength=Gc)   # restricted residual sums

    if weights == "webb":
        W = rng.choice(WEBB, size=(B, Gc))
    else:
        W = rng.choice([-1.0, 1.0], size=(B, Gc))
    WS = W * S0                                                 # bootstrap cluster sums of y* - ybar
    mean1 = WS[:, arm].sum(1) / n1
    mean0 = WS[:, ~arm].sum(1) / n0
    beta_b = mean1 - mean0
    E = WS - np.where(arm, mean1[:, None], mean0[:, None]) * m_c[None, :]
    v = ((E[:, arm] / n1) ** 2).sum(1) + ((E[:, ~arm] / n0) ** 2).sum(1)
    v *= Gc / (Gc - 1) * (N - 1) / (N - 2)
    t_b = beta_b / np.sqrt(v)
    return float(beta), float((np.abs(t_b) >= abs(t_obs)).mean())


def _p_from_t(beta, se, df):
    return float(2 * stats.t.sf(abs(beta / se), df))


def analyse(data, rng, B=399) -> dict[str, float]:
    """p-values of all estimators for one simulated dataset."""
    y, t = data["y"], data["treat"]
    out = {"ols_iid": _p_from_t(*ols_iid(y, t))}
    for name, key in (("cr_subject", "subject"), ("cr_group", "group"), ("cr_session", "session")):
        out[name] = _p_from_t(*ols_cluster(y, t, data[key]))
    out["session_means"] = session_means_test(y, t, data["session"])[1]
    out["wild_session"] = wild_cluster_bootstrap(y, t, data["session"], rng, B=B)[1]
    return out


# ------------------------------------------------------------------ power curves
def rejection_rates(d: Design, reps=1000, alpha=0.05, B=399, seed=1) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    pv = pd.DataFrame([analyse(simulate_data(d, rng), rng, B=B) for _ in range(reps)])
    rate = (pv < alpha).mean()
    mcse = np.sqrt(rate * (1 - rate) / reps)
    out = pd.DataFrame({"estimator": rate.index, "rejection_rate": rate.values, "mc_se": mcse.values})
    for k, v in asdict(d).items():
        out[k] = v
    return out


def power_grid(base: Design, sessions=(2, 3, 4, 6, 8, 10), effects=(0.0, 0.10), reps=1000, B=399, seed=1) -> pd.DataFrame:
    frames = []
    for i, s in enumerate(sessions):
        for j, eff in enumerate(effects):
            frames.append(rejection_rates(replace(base, sessions_per_arm=s, effect=eff), reps=reps, B=B, seed=seed + 100 * i + j))
    return pd.concat(frames, ignore_index=True)


# ------------------------------------------------------------------ analytic benchmarks
def design_effect(cluster_size: float, icc: float) -> float:
    """Kish design effect 1 + (m - 1) ICC for equal cluster sizes."""
    return 1 + (cluster_size - 1) * icc


def session_mean_variance(d: Design) -> float:
    """Variance of a session mean in the uncensored model."""
    var = d.sd ** 2
    G, n, R = d.groups_per_session, d.group_size, d.rounds
    resid = 1 - d.icc_session - d.icc_group - d.icc_subject
    return var * (d.icc_session + d.icc_group / G + d.icc_subject / (G * n) + resid / (G * n * R))


def analytic_power_session_means(d: Design, alpha=0.05) -> float:
    """Power of the two-sample t-test on session means (pooled-variance approximation, uncensored model)."""
    k = d.sessions_per_arm
    se = np.sqrt(2 * session_mean_variance(d) / k)
    df = 2 * k - 2
    ncp = d.effect / se
    crit = stats.t.ppf(1 - alpha / 2, df)
    return float(stats.nct.sf(crit, df, ncp) + stats.nct.cdf(-crit, df, ncp))


def required_sessions(d: Design, power=0.8, alpha=0.05, max_sessions=60) -> int | None:
    """Smallest number of sessions per arm reaching the target power (analytic, session-means test)."""
    for k in range(2, max_sessions + 1):
        if analytic_power_session_means(replace(d, sessions_per_arm=k), alpha) >= power:
            return k
    return None
